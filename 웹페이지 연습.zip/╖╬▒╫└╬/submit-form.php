<?php
// submit-form.php 파일 내용
// 데이터베이스에 회원 정보를 저장하는 등의 작업을 수행합니다.

// 로그인 페이지로 이동합니다.
header("Location: login.php");
exit;
?>
