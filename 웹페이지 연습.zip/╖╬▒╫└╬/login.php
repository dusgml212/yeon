<?php
// 데이터베이스 연결 정보
$servername = "localhost";
$username = "db_username";
$password = "db_password";
$dbname = "db_name";

// 데이터베이스 연결 생성
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 로그인 버튼 클릭 시 처리
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // SQL 쿼리 생성 및 실행
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    // 로그인 성공 시 세션 생성 및 메인 페이지로 이동
    if ($result->num_rows > 0) {
        session_start();
        $_SESSION["username"] = $username;
        header("Location: main.php");
    } else {
        // 로그인 실패 시 에러 메시지 출력
        echo "아이디 또는 비밀번호가 일치하지 않습니다.";
    }
}

// 데이터베이스 연결 종료
$conn->close();
?>
